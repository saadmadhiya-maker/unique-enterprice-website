Unique Enterprice - DEVELOPER HANDOVER
Updated 7 October 2026

Open index.html or serve this folder with any static web server.
Upload the folder contents to the hosting document root. No build step is needed.
index.html contains the complete page; style.css and script.js contain styles
and interactions. All website images are in images/.

WhatsApp: +91 8735957393 (header, contact section and floating CTA).
Email: uniqueenterprise393@gmail.com.
Existing voice-call number retained: +91 8735057393.
Original design and animation code retained, with supplied logo replacement.

SEO includes title, description, canonical URL, social metadata,
LocalBusiness/WebSite JSON-LD, image dimensions/lazy loading, robots and sitemap.
Current canonical origin: https://unique-enterprise.dmfaizan44.chatgpt.site
For custom domain deployment, update that origin throughout index.html,
robots.txt and sitemap.xml, including absolute social and JSON-LD image URLs.
Verify your domain in Google Search Console and submit sitemap.xml.
Search Console submission and indexing have not been performed; rankings are
not guaranteed. Preserve existing email DNS when configuring a custom domain.

This is a static HTML/CSS/JavaScript export, not an Elementor import template.
A developer can integrate it into a WordPress page/theme, preserving asset URLs
and script loading. Contact links open phone/email/WhatsApp apps; there is no
backend lead storage.

Checked: JS syntax, local HTML assets, contacts, JSON-LD and sitemap parsing.
Browser and device visual testing should be performed before custom deployment.

LATEST REVISION
Reference-sized logo spacing, WhatsApp brand icons and updated office address:
Ground Floor, Shed No. 5, Plot No. 4610/B, Shaili Engineering Work,
East 14 Road, Ankleshwar, Bharuch, Gujarat - 393002.
Includes matching structured-data address.
