const toggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('.mobile-nav');
const openIcon = toggle.innerHTML;
function setMenu(open) {
 nav.classList.toggle('is-open', open);
 toggle.setAttribute('aria-expanded', String(open));
 toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
 toggle.innerHTML = open ? '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m6 6 12 12M6 18 18 6"/></svg>' : openIcon;
}
toggle.addEventListener('click', () => setMenu(toggle.getAttribute('aria-expanded') !== 'true'));
nav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => setMenu(false)));
document.addEventListener('keydown', e => { if(e.key === 'Escape') setMenu(false); });
const observer = new IntersectionObserver(entries => entries.forEach(entry => { if(entry.isIntersecting) entry.target.classList.add('is-visible'); }), {threshold: .12});
document.querySelectorAll('.ue-reveal').forEach(el => observer.observe(el));
